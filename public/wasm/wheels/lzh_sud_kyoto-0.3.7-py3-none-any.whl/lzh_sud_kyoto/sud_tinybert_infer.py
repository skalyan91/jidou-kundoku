#!/usr/bin/env python
"""Inference-only TinyBERT tok2vec: numpy forward pass + pure-python WordPiece, NO torch, NO transformers.

`sud.TinyBertNumpy.v1` / `sud.TinyBertPlusHashNumpy.v1` reproduce, number for number,
`sud.TinyBertTok2Vec.v1` / `sud.TinyBertPlusHash.v1` from `sud_tinybert_embed.py` (the TRAINING module,
which needs torch + transformers and is left untouched):

  words -> WordPiece (same normalisation as the HF `BertTokenizerFast` used in training: clean-text,
  CJK spacing, accent strip + lowercase, whitespace/punctuation pre-split, greedy longest-match)
  -> chunks of <= `max_len` pieces split only BETWEEN words, [CLS]/[SEP] added, whitespace-only tokens
  fall back to [UNK] -> L-layer BERT in numpy (post-LN, exact-erf GELU) keeping all 5 hidden states
  -> gamma * softmax(mix_logits)-weighted sum -> the FIRST piece of each word.

SEALING (CLAUDE.md standing hazard 4). The config names NO file. The BERT weights, the 30 522-entry
vocab, the BERT hyper-parameters, the layer-mix logits and gamma all live in the component's own
`to_disk` bytes: the numpy encoder is a thinc `Shim` whose `to_bytes` carries all of it, so the
`tok2vec/model` file of the packaged wheel is self-contained and loading never opens a path.
An unfilled shim (weights not yet loaded) REFUSES to run rather than emit zeros.

Weights are converted from a trained torch arm by `scripts/seal_tinybert_tok2vec.py`.

STORAGE DTYPE (ko 0.3.1). The sealed arrays are float32 unless `meta["storage"] = {"dtype": "float16", "keys": [...]}`
names the tensors that are stored as float16 to halve the file; the forward pass is float32 either way, so only the
STORAGE is rounded. The word-embedding matrix is upcast per gathered row; every other
float16 tensor is upcast each time it is used, so only float16 copies stay resident. A loader that meets a storage dtype it does not know, a listed key that is
absent, or an array whose dtype contradicts the declaration REFUSES instead of guessing (CLAUDE.md hazard 8).

INT8 WORD MATRIX (lzh 0.3.6). `storage["int8"] = {"keys": ["word"], "scales": {"word": "word.scale"}, "group": G}` stores the
word-embedding matrix as int8 with one float16 scale per G columns of each row (G = the full width = per-row scale), listed
in `storage["keys"]` so it is float16 like every other scale. Only the rows a call gathers are dequantised, to float32; the
full matrix is never materialised. The loader refuses an int8 key other than `word`, an absent scale tensor, an array whose
dtype contradicts the declaration, and a scale whose shape is not (rows, columns // G) (hazard 8).

CHAR MAP (zh 0.3.0). `meta["char_map"]` = {char: char} is applied to every word, character by character, BEFORE word-piece
lookup (the hash-embed CNN beside the encoder still reads the original text): zh feeds the encoder SIMPLIFIED forms of the
traditional text it parses, because minirbt learned the simplified characters far better. The map is one-to-one per character, so
word/piece alignment is untouched; it is sealed in the weights and absent (= identity) in every earlier wheel.

Licence of the encoder weights and vocab: TinyBERT_General_4L_312D (en) and lassl/bert-ko-small (ko), both
Apache-2.0 (see the wheel NOTICE). Layer count, width, heads, eps, casing and accent stripping are all read from
the sealed meta, so the same forward pass serves the 4L-312D English encoder and the 12L-256D Korean one.
"""
import math
import re
import unicodedata
from typing import Dict, List

import numpy
import srsly
from spacy import registry
from spacy.ml.models.tok2vec import build_Tok2Vec_model
from spacy.tokens import Doc
from thinc.api import Model, concatenate
from thinc.shims import Shim
from thinc.types import Floats2d
from thinc.util import convert_recursive, is_xp_array

# --------------------------------------------------------------------------------------- WordPiece


def _is_cjk(cp: int) -> bool:
    return (
        0x4E00 <= cp <= 0x9FFF or 0x3400 <= cp <= 0x4DBF or 0x20000 <= cp <= 0x2A6DF
        or 0x2A700 <= cp <= 0x2B73F or 0x2B740 <= cp <= 0x2B81F or 0x2B820 <= cp <= 0x2CEAF
        or 0xF900 <= cp <= 0xFAFF or 0x2F800 <= cp <= 0x2FA1F
    )


def _is_punct(c: str) -> bool:
    cp = ord(c)
    if 33 <= cp <= 47 or 58 <= cp <= 64 or 91 <= cp <= 96 or 123 <= cp <= 126:
        return True
    return unicodedata.category(c).startswith("P")


def _is_ws(c: str) -> bool:
    # controls (other than \t \n \r) are already dropped, so str.isspace matches the Rust White_Space set
    return c.isspace()


def _normalise(word: str, lowercase: bool = True, strip_accents: bool = True) -> str:
    """The HF BertNormalizer (clean_text, handle_chinese_chars, strip_accents, lowercase), in order.

    `lowercase=False, strip_accents=False` is a CASED vocabulary such as lassl/bert-ko-small's: HF then does
    neither, and in particular no NFD, which would split every Hangul syllable into jamo."""
    out = []
    for c in word:
        if c == "\0" or c == "�":
            continue
        if c not in "\t\n\r" and unicodedata.category(c) in ("Cc", "Cf", "Co"):
            continue
        if _is_ws(c):
            out.append(" ")
        elif _is_cjk(ord(c)):
            out.append(" " + c + " ")
        else:
            out.append(c)
    s = "".join(out)
    if strip_accents:
        s = "".join(ch for ch in unicodedata.normalize("NFD", s) if unicodedata.category(ch) != "Mn")
    # per character: str.lower() on the whole string applies the final-sigma rule (word-final Σ -> ς), HF lowercases
    # each character on its own (Σ -> σ), and a different piece id follows
    return "".join(c.lower() for c in s) if lowercase else s


def _pre_split(s: str) -> List[str]:
    """Whitespace split, then each punctuation character is its own pre-token."""
    toks = []
    for chunk in s.split():
        cur = []
        for c in chunk:
            if _is_punct(c):
                if cur:
                    toks.append("".join(cur))
                    cur = []
                toks.append(c)
            else:
                cur.append(c)
        if cur:
            toks.append("".join(cur))
    return toks


class WordPiece:
    def __init__(self, vocab: List[str], unk: str = "[UNK]", max_chars: int = 100,
                 lowercase: bool = True, strip_accents: bool = True):
        self.lowercase, self.strip_accents = lowercase, strip_accents
        self.vocab = {t: i for i, t in enumerate(vocab)}
        self.unk, self.unk_id = unk, self.vocab[unk]
        self.cls_id, self.sep_id, self.pad_id = self.vocab["[CLS]"], self.vocab["[SEP]"], self.vocab["[PAD]"]
        self.max_chars = max_chars
        self._specials = {"[PAD]", "[UNK]", "[CLS]", "[SEP]", "[MASK]"}
        self._special_re = re.compile("(" + "|".join(re.escape(t) for t in sorted(self._specials)) + ")")
        self._cache: Dict[str, List[int]] = {}

    def _piece(self, tok: str) -> List[int]:
        if len(tok) > self.max_chars:
            return [self.unk_id]
        out, start = [], 0
        while start < len(tok):
            end, cur = len(tok), None
            while start < end:
                sub = tok[start:end]
                if start > 0:
                    sub = "##" + sub
                if sub in self.vocab:
                    cur = self.vocab[sub]
                    break
                end -= 1
            if cur is None:
                return [self.unk_id]
            out.append(cur)
            start = end
        return out

    def word(self, word: str) -> List[int]:
        """Word-piece ids of ONE already-isolated word (a spaCy token); [] if it normalises to nothing."""
        hit = self._cache.get(word)
        if hit is None:
            hit = []
            # HF splits ADDED/special tokens out of the raw text first, so a literal "[SEP]" is id 102
            for part in self._special_re.split(word):
                if part in self._specials:
                    hit.append(self.vocab[part])
                    continue
                for tok in _pre_split(_normalise(part, self.lowercase, self.strip_accents)):
                    hit.extend(self._piece(tok))
            if len(self._cache) < 200_000:
                self._cache[word] = hit
        return hit


# ------------------------------------------------------------------------------------------ BERT


def _erf(x: numpy.ndarray) -> numpy.ndarray:
    # Abramowitz & Stegun 7.1.26 is only 1.5e-7; use the Numerical-Recipes erfc Chebyshev fit (<1.2e-7
    # RELATIVE) via float64 so GELU matches torch's exact-erf GELU far below the 1e-4 tolerance.
    z = numpy.abs(x.astype(numpy.float64))
    t = 1.0 / (1.0 + 0.5 * z)
    poly = -z * z - 1.26551223 + t * (1.00002368 + t * (0.37409196 + t * (0.09678418 + t * (
        -0.18628806 + t * (0.27886807 + t * (-1.13520398 + t * (1.48851587 + t * (-0.82215223 + t * 0.17087277))))))))
    erfc = t * numpy.exp(poly)
    r = 1.0 - erfc
    return numpy.where(x >= 0, r, -r).astype(x.dtype)


def _gelu(x: numpy.ndarray) -> numpy.ndarray:
    return 0.5 * x * (1.0 + _erf(x * numpy.float32(1.0 / math.sqrt(2.0))))


def _layer_norm(x, g, b, eps):
    mu = x.mean(-1, keepdims=True)
    var = ((x - mu) ** 2).mean(-1, keepdims=True)
    return (x - mu) / numpy.sqrt(var + eps) * g + b


def quantize_rows(m: numpy.ndarray, group: int):
    """Symmetric int8 with one float16 scale per `group` columns of each row: returns (int8 (n, c), float16 (n, c // group)).
    The scale is rounded to float16 BEFORE the division, so the stored scale is exactly the one the rows were quantised with."""
    n, c = m.shape
    if group <= 0 or c % group:
        raise ValueError(f"sud.TinyBertNumpy: int8 group {group} does not divide the width {c}")
    x = numpy.asarray(m, dtype=numpy.float32).reshape(n, c // group, group)
    sc = (numpy.abs(x).max(-1) / 127.0).astype(numpy.float16)
    sc32 = sc.astype(numpy.float32)
    sc32[sc32 == 0] = 1.0
    q = numpy.clip(numpy.rint(x / sc32[..., None]), -127, 127).astype(numpy.int8)
    return q.reshape(n, c), sc


class _F32View:
    """`w[name]` as float32: a float16-stored tensor is upcast per use (a copy), a float32 one is returned as is."""

    def __init__(self, w):
        self._w = w

    def __getitem__(self, k):
        v = self._w[k]
        return v if v.dtype == numpy.float32 else v.astype(numpy.float32)


class NumpyBert(Shim):
    """Holds every weight; `to_bytes`/`from_bytes` seal them (and the vocab) into the model file."""

    def __init__(self, max_len: int = 256, char_map_size: int = 0):
        super().__init__(None)
        self.max_len = max_len
        self.char_map_size = char_map_size   # how many characters the CONFIG says the sealed map holds (0 = none expected)
        self.meta: Dict = {}
        self.w: Dict[str, numpy.ndarray] = {}
        self.vocab_list: List[str] = []
        self._half: set = set()
        self._q8: dict = {}
        self._tok = None

    # ---- (de)serialisation: everything is in these bytes, nothing is read from a path
    def set_weights(self, meta, vocab_list, weights):
        """`weights` may be float32 (build time: tensors named in `meta["storage"]["keys"]` are ROUNDED to float16 here,
        so the in-memory twin is exactly what the file will hold) or already float16 (load)."""
        self.meta, self.vocab_list = dict(meta), list(vocab_list)
        st = self.meta.get("storage")
        half, q8 = set(), {}
        if st is not None:
            if st.get("dtype") != "float16":
                raise ValueError(f"sud.TinyBertNumpy: unsupported weight storage {st!r}; this loader reads float32 and "
                                 "float16 only (refusing to guess)")
            half = set(st.get("keys", []))
            if half - set(weights):
                raise ValueError(f"sud.TinyBertNumpy: storage names tensors that are absent: {sorted(half - set(weights))}")
            if st.get("int8") is not None:
                q8 = self._check_int8(st["int8"], weights, half)
        self.w = {}
        for k, v in weights.items():
            if k in q8:
                self.w[k] = numpy.ascontiguousarray(v, dtype=numpy.int8)
            elif k in half:
                # stays half-width in memory (the word matrix is upcast per gathered row, every other tensor per use):
                # the resident encoder is half the size, and an upcast of one layer's matrices is a few ms
                self.w[k] = numpy.ascontiguousarray(v, dtype=numpy.float16)
            else:
                self.w[k] = numpy.ascontiguousarray(v, dtype=numpy.float32)
        self._half, self._q8 = half, q8
        self._tok = None
        got = len((self.meta.get("char_map") or {}))
        if got != self.char_map_size:
            # a lost map would load, run and quietly feed the encoder the traditional text it handles badly (zh: -2.7 LAS)
            raise ValueError(f"sud.TinyBertNumpy: the config expects a sealed character map of {self.char_map_size} "
                             f"characters but the weights carry {got} (refusing to guess)")
        return self

    @staticmethod
    def _check_int8(spec, weights, half):
        known = {"keys", "scales", "group"}
        if set(spec) - known:
            raise ValueError(f"sud.TinyBertNumpy: unknown int8 storage fields {sorted(set(spec) - known)} (refusing to guess)")
        keys, scales, group = list(spec.get("keys", [])), dict(spec.get("scales", {})), spec.get("group")
        if keys != ["word"]:
            raise ValueError(f"sud.TinyBertNumpy: int8 storage is implemented for the word matrix only, not {keys!r}")
        if "word" in half:
            raise ValueError("sud.TinyBertNumpy: 'word' is declared both float16 and int8 (refusing to guess)")
        if "word" not in weights:
            raise ValueError("sud.TinyBertNumpy: int8 storage names 'word', which is absent")
        sk = scales.get("word")
        if sk is None or sk not in weights:
            raise ValueError(f"sud.TinyBertNumpy: int8 storage names the scale tensor {sk!r}, which is absent")
        if sk not in half:
            raise ValueError(f"sud.TinyBertNumpy: the int8 scale {sk!r} must be listed as float16 storage")
        n, c = numpy.asarray(weights["word"]).shape
        if not isinstance(group, int) or group <= 0 or c % group:
            raise ValueError(f"sud.TinyBertNumpy: int8 group {group!r} does not divide the width {c}")
        if numpy.asarray(weights[sk]).shape != (n, c // group):
            raise ValueError(f"sud.TinyBertNumpy: int8 scale {sk!r} has shape {numpy.asarray(weights[sk]).shape}, "
                             f"expected {(n, c // group)}")
        return {"word": sk}

    def word_rows(self, ids) -> numpy.ndarray:
        """The word-embedding rows for `ids` as float32; an int8 matrix is dequantised for these rows only."""
        rows = self.w["word"][ids]
        if not self._q8:
            return numpy.asarray(rows, dtype=numpy.float32)
        sc = self.w[self._q8["word"]][ids].astype(numpy.float32)            # (n, groups)
        n, c = rows.shape
        return (rows.astype(numpy.float32).reshape(n, sc.shape[1], c // sc.shape[1]) * sc[:, :, None]).reshape(n, c)

    def to_bytes(self):
        out = {k: (v.astype(numpy.float16) if k in self._half and v.dtype != numpy.float16 else v)
               for k, v in self.w.items()}
        return srsly.msgpack_dumps({"meta": self.meta, "vocab": self.vocab_list, "w": out, "max_len": self.max_len})

    def from_bytes(self, data):
        msg = srsly.msgpack_loads(data)
        self.max_len = int(msg["max_len"])
        st = (msg["meta"] or {}).get("storage")
        for k, v in msg["w"].items():
            want = "float16" if st is not None and k in st.get("keys", []) else "float32"
            if st is not None and k in ((st.get("int8") or {}).get("keys") or []):
                want = "int8"
            if st is not None and st.get("dtype") != "float16":
                break  # set_weights raises with the real reason
            if numpy.asarray(v).dtype != numpy.dtype(want):
                raise ValueError(f"sud.TinyBertNumpy: tensor {k!r} is stored as {numpy.asarray(v).dtype} but the "
                                 f"sealed storage declaration says {want} (refusing to guess)")
        return self.set_weights(msg["meta"], msg["vocab"], msg["w"])

    def to_device(self, device_type, device_id):
        pass

    def finish_update(self, optimizer):
        pass

    def __call__(self, inputs, is_train):
        raise NotImplementedError("sud.TinyBertNumpy is inference-only")

    @property
    def char_map(self) -> Dict[str, str]:
        return self.meta.get("char_map") or {}

    def map_words(self, words: List[str]) -> List[str]:
        """The sealed character map applied to each word (identity when the weights carry none)."""
        cm = self.char_map
        return [w if not cm else "".join(cm.get(c, c) for c in w) for w in words]

    @property
    def tok(self) -> WordPiece:
        if not self.w:
            raise ValueError("sud.TinyBertNumpy has no weights: the model was built from config but never loaded "
                             "from its serialised bytes (refusing to emit zeros)")
        if self._tok is None:
            # meta keys absent in the 0.3.0 en weights: those were uncased and accent-stripped
            self._tok = WordPiece(self.vocab_list, lowercase=bool(self.meta.get("lowercase", True)),
                                  strip_accents=bool(self.meta.get("strip_accents", True)))
        return self._tok

    # ---- forward
    def hidden_states(self, ids: List[int]) -> List[numpy.ndarray]:
        m = self.meta
        w = _F32View(self.w)
        H, nh, eps = m["hidden"], m["heads"], m["eps"]
        dh = H // nh
        n = len(ids)
        x = self.word_rows(ids) + w["pos"][:n] + w["type0"]
        x = _layer_norm(x, w["emb_g"], w["emb_b"], eps)
        hs = [x]
        scale = numpy.float32(1.0 / math.sqrt(dh))
        for i in range(m["layers"]):
            p = f"l{i}."
            q = (x @ w[p + "q_w"] + w[p + "q_b"]).reshape(n, nh, dh).transpose(1, 0, 2)
            k = (x @ w[p + "k_w"] + w[p + "k_b"]).reshape(n, nh, dh).transpose(1, 2, 0)
            v = (x @ w[p + "v_w"] + w[p + "v_b"]).reshape(n, nh, dh).transpose(1, 0, 2)
            s = (q @ k) * scale
            s -= s.max(-1, keepdims=True)
            e = numpy.exp(s)
            a = e / e.sum(-1, keepdims=True)
            ctx = (a @ v).transpose(1, 0, 2).reshape(n, H)
            x = _layer_norm(x + ctx @ w[p + "o_w"] + w[p + "o_b"], w[p + "ao_g"], w[p + "ao_b"], eps)
            h = _gelu(x @ w[p + "i_w"] + w[p + "i_b"])
            x = _layer_norm(x + h @ w[p + "f_w"] + w[p + "f_b"], w[p + "fo_g"], w[p + "fo_b"], eps)
            hs.append(x)
        return hs

    def mixed(self, ids: List[int]) -> numpy.ndarray:
        hs = self.hidden_states(ids)
        lg = self.w["mix_logits"].astype(numpy.float64)
        wts = numpy.exp(lg - lg.max())
        wts = (wts / wts.sum()).astype(numpy.float32)
        out = wts[0] * hs[0]
        for i in range(1, len(hs)):
            out = out + wts[i] * hs[i]
        return out * self.w["gamma"][0]


def encode_chunks(tok: WordPiece, words: List[str], max_len: int):
    """Mirror of `_encode` in sud_tinybert_embed.py for ONE doc: [(ids, first-piece offsets)]."""
    chunks = []
    ids, firsts = [tok.cls_id], []
    for word in words:
        p = tok.word(word) or [tok.unk_id]
        if len(ids) + len(p) > max_len - 1 and firsts:
            chunks.append((ids + [tok.sep_id], firsts))
            ids, firsts = [tok.cls_id], []
        firsts.append(len(ids))
        ids.extend(p[: max_len - 2])
    chunks.append((ids + [tok.sep_id], firsts))
    return chunks


def _forward(model: Model, docs: List[Doc], is_train: bool):
    if is_train:
        raise ValueError("sud.TinyBertNumpy is inference-only; train with sud.TinyBertTok2Vec.v1 (torch)")
    shim: NumpyBert = model.shims[0]
    out = []
    for doc in docs:
        words = [t.text for t in doc]
        if not words:
            out.append(numpy.zeros((0, model.get_dim("nO")), dtype="float32"))
            continue
        rows = []
        for ids, firsts in encode_chunks(shim.tok, shim.map_words(words), shim.max_len):
            rows.append(shim.mixed(ids)[firsts])
        out.append(numpy.concatenate(rows, axis=0).astype("float32", copy=False))
    return out, lambda dY: []


@registry.architectures.register("sud.TinyBertNumpy.v1")
def TinyBertNumpy(hidden: int = 312, max_len: int = 256, char_map_size: int = 0) -> Model[List[Doc], List[Floats2d]]:
    """Weights are NOT in the config: they arrive through `Model.from_bytes` (the component's own bytes).
    `char_map_size` is the number of characters in the sealed map (0 = none); a mismatch refuses to load."""
    return Model("sud.tinybert_numpy", _forward, dims={"nO": hidden}, shims=[NumpyBert(max_len, char_map_size)])


@registry.architectures.register("sud.TinyBertPlusHashNumpy.v1")
def TinyBertPlusHashNumpy(embed: Model, encode: Model, hidden: int = 312, max_len: int = 256, char_map_size: int = 0):
    """The numpy twin of `sud.TinyBertPlusHash.v1`: encoder beside spaCy's hash-embed CNN, concatenated."""
    return concatenate(TinyBertNumpy(hidden, max_len, char_map_size), build_Tok2Vec_model(embed, encode))


# ------------------------------------------------------------------ fp16 STORAGE of the thinc weights (zh 0.3.0)
#
# The hash-embed CNNs, the parser, the morphologiser, the lemmatiser and the tagger are ordinary thinc models whose
# `model` file is `Model.to_bytes()` (msgpack, float32 arrays). `scripts/store_thinc_fp16.py` re-stores the arrays under
# `params` as float16 to halve the file; the compute stays float32 because the loader upcasts every float16 array BEFORE
# thinc sees it. The file is then a CONTAINER, `{"sud_storage": {format, dtype, leaves}, "model": <thinc bytes>}`, so a
# loader that does not know the format fails on the missing `nodes` key instead of reading float16 weights as if they were
# the parameters. The container declares the dtype of EVERY array leaf by path; the loader refuses an unknown format or
# dtype, a declaration that omits or invents a leaf, and any array whose dtype contradicts its declaration (hazard 8).
# A file with no container is read as before, but is refused if it holds a float16 array that nothing declared.

_THINC_FP16_FORMAT = 1


def _array_leaves(o, path=""):
    if isinstance(o, numpy.ndarray):
        yield path, o
    elif isinstance(o, dict):
        for k, v in o.items():
            yield from _array_leaves(v, f"{path}/{k}")
    elif isinstance(o, (list, tuple)):
        for i, v in enumerate(o):
            yield from _array_leaves(v, f"{path}/{i}")


def _map_arrays(o, fn, path=""):
    if isinstance(o, numpy.ndarray):
        return fn(path, o)
    if isinstance(o, dict):
        return {k: _map_arrays(v, fn, f"{path}/{k}") for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_map_arrays(v, fn, f"{path}/{i}") for i, v in enumerate(o)]
    return o


def pack_thinc_fp16(model_bytes: bytes) -> bytes:
    """`Model.to_bytes()` -> the container: every float32 array under `params` stored as float16 (finite or it raises)."""
    msg = srsly.msgpack_loads(model_bytes)

    def down(path, a):
        if not path.startswith("/params/") or a.dtype != numpy.float32:
            return a
        h = a.astype(numpy.float16)
        if not numpy.isfinite(h).all():
            raise ValueError(f"fp16 storage overflows at {path}: max |w| = {float(numpy.abs(a).max())}")
        return h

    stored = _map_arrays(msg, down)
    leaves = {p: str(a.dtype) for p, a in _array_leaves(stored)}
    decl = {"format": _THINC_FP16_FORMAT, "dtype": "float16", "leaves": leaves}
    return srsly.msgpack_dumps({"sud_storage": decl, "model": srsly.msgpack_dumps(stored)})


def _thinc_fp16_msg(data: bytes, what: str):
    """The container -> the plain float32 thinc message (a dict); None when `data` is not a container (a legacy float32 file)."""
    outer = srsly.msgpack_loads(data)
    if not (isinstance(outer, dict) and "sud_storage" in outer):
        if any(a.dtype == numpy.float16 for _, a in _array_leaves(outer)):
            raise ValueError(f"{what}: holds float16 arrays but declares no storage (refusing to read them as parameters)")
        return None
    decl = outer["sud_storage"]
    if set(outer) != {"sud_storage", "model"} or not isinstance(outer["model"], (bytes, bytearray)):
        raise ValueError(f"{what}: unknown storage container layout {sorted(map(str, outer))}")
    if not isinstance(decl, dict) or set(decl) != {"format", "dtype", "leaves"} or not isinstance(decl["leaves"], dict):
        raise ValueError(f"{what}: malformed storage declaration")
    if decl["format"] != _THINC_FP16_FORMAT:
        raise ValueError(f"{what}: storage format {decl['format']!r} is not {_THINC_FP16_FORMAT}")
    if decl["dtype"] != "float16":
        raise ValueError(f"{what}: unknown storage dtype {decl['dtype']!r} (this loader knows float16)")
    msg = srsly.msgpack_loads(bytes(outer["model"]))
    actual = {p: str(a.dtype) for p, a in _array_leaves(msg)}
    declared = {str(k): str(v) for k, v in decl["leaves"].items()}
    if set(actual) != set(declared):
        raise ValueError(f"{what}: declaration and arrays disagree on {sorted(set(actual) ^ set(declared))[:4]}")
    bad = [p for p in actual if actual[p] != declared[p]]
    if bad:
        raise ValueError(f"{what}: {bad[0]} is {actual[bad[0]]} but declared {declared[bad[0]]}")
    if "nodes" not in msg or not any(v == "float16" for v in declared.values()):
        raise ValueError(f"{what}: container holds no float16 array / no thinc model")
    return _map_arrays(msg, lambda p, a: a.astype(numpy.float32) if a.dtype == numpy.float16 else a)


def unpack_thinc_fp16(data: bytes, what: str = "model") -> bytes:
    """The container -> plain float32 `Model.to_bytes()` bytes (identity on a file that is not a container)."""
    msg = _thinc_fp16_msg(data, what)
    return data if msg is None else srsly.msgpack_dumps(msg)


_FP16_CLASSES: Dict[type, type] = {}


def _fp16_class(base: type) -> type:
    if base not in _FP16_CLASSES:
        def from_bytes(self, bytes_data):
            msg = _thinc_fp16_msg(bytes_data, f"{self.name} model")
            if msg is None:
                return base.from_bytes(self, bytes_data)
            if getattr(base.from_bytes, "__func__", base.from_bytes) is Model.from_bytes:
                return self.from_dict(convert_recursive(is_xp_array, self.ops.asarray, msg))  # Model.from_bytes, minus the re-serialising
            return base.from_bytes(self, srsly.msgpack_dumps(msg))

        _FP16_CLASSES[base] = type(base.__name__, (base,), {"__slots__": (), "from_bytes": from_bytes, "_sud_fp16": True})
    return _FP16_CLASSES[base]


@registry.callbacks("sud.fp16_thinc_storage.v1")
def fp16_thinc_storage():
    """`[nlp] after_pipeline_creation`: every pipe's thinc model reads its `model` file through `unpack_thinc_fp16`."""
    def patch(nlp):
        for _, pipe in nlp.pipeline:
            m = getattr(pipe, "model", None)
            if isinstance(m, Model) and not getattr(type(m), "_sud_fp16", False):
                m.__class__ = _fp16_class(type(m))
        return nlp

    return patch
