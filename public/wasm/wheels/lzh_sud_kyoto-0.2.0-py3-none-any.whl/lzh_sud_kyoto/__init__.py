from pathlib import Path
from spacy.util import load_model_from_init_py, get_model_meta

from . import sud_misc
from . import sud_idiom
from . import sud_shared_data
from . import sud_tagger
from . import lzh_tokenizer
from . import clause_parser
from . import han_lemma_lut
from . import sud_subject_rule
from . import sud_subject_frames
from . import char_seg_tokenizer
from . import sa_presegment
from . import sa_presegment_lex
from . import sud_feats_embed

__version__ = get_model_meta(Path(__file__).parent)['version']


def load(**overrides):
    return load_model_from_init_py(__file__, **overrides)
