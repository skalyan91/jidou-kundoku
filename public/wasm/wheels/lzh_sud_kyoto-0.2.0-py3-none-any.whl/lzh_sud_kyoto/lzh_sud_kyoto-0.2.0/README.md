| Feature | Description |
| --- | --- |
| **Name** | `lzh_sud_kyoto` |
| **Version** | `0.2.0` |
| **spaCy** | `>=3.8.14,<3.9.0` |
| **Default Pipeline** | `tok2vec`, `parser`, `morphologizer`, `tagger`, `sud_shared`, `han_lemma_lut`, `sud_subject_rule`, `sud_idiom` |
| **Components** | `tok2vec`, `parser`, `morphologizer`, `tagger`, `sud_shared`, `han_lemma_lut`, `sud_subject_rule`, `sud_idiom` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | [SUD_Classical_Chinese-Kyoto](https://github.com/surfacesyntacticud/SUD_Classical_Chinese-Kyoto)<br>[Kanseki Repository (punctuation)](https://github.com/kanripo) |
| **License** | `CC BY-SA 4.0` |
| **Author** | [Sunflower AI](https://github.com/SunflowerAI/sud-spacy-parsers) |

### Label Scheme

<details>

<summary>View label scheme (315 labels for 4 components)</summary>

| Component | Labels |
| --- | --- |
| **`parser`** | `ROOT`, `cc`, `clf`, `comp:aux`, `comp:obj`, `comp:obl`, `comp:obl@lmod`, `comp:pred`, `comp@expl`, `compound`, `compound@redup`, `conj:coord`, `conj:coord@emb`, `dep`, `det`, `discourse`, `discourse@sp`, `dislocated`, `flat`, `flat@foreign`, `flat@vv`, `list`, `mod`, `mod@lmod`, `mod@tmod`, `parataxis`, `punct`, `subj`, `udep`, `udep@lmod`, `udep@tmod`, `unk`, `unk@expl`, `vocative` |
| **`morphologizer`** | `POS=VERB`, `POS=NOUN`, `POS=NUM`, `POS=PUNCT`, `POS=AUX\|VerbType=Cop`, `POS=ADV\|Polarity=Neg`, `POS=NOUN\|Shared=No`, `POS=ADV`, `Mood=Pot\|POS=AUX`, `Degree=Pos\|POS=VERB\|VerbForm=Part`, `POS=PART`, `Degree=Pos\|POS=VERB`, `POS=VERB\|VerbForm=Part`, `POS=ADV\|Shared=Yes`, `POS=PART\|Shared=Yes`, `POS=VERB\|Shared=No`, `POS=ADP`, `POS=ADV\|Polarity=Neg\|VerbForm=Conv`, `POS=PRON\|PronType=Dem`, `POS=SCONJ`, `POS=PRON\|Person=3\|PronType=Prs`, `ExtPos=ADV\|POS=ADV`, `POS=VERB\|Polarity=Neg`, `Case=Loc\|POS=NOUN`, `POS=ADV\|VerbForm=Conv`, `POS=PRON\|Person=1\|PronType=Prs`, `Case=Tem\|POS=NOUN`, `AdvType=Tim\|POS=ADV`, `POS=CCONJ`, `POS=PRON\|PronType=Int`, `Degree=Equ\|POS=VERB`, `POS=PRON\|PronType=Prs\|Reflex=Yes`, `NameType=Giv\|POS=PROPN`, `NameType=Prs\|POS=PROPN`, `Degree=Pos\|POS=ADV\|VerbForm=Conv`, `Mood=Des\|POS=AUX`, `POS=ADP\|Shared=No`, `NameType=Sur\|POS=PROPN`, `Degree=Equ\|POS=VERB\|VerbForm=Part`, `Case=Loc\|NameType=Nat\|POS=PROPN`, `POS=PRON\|Person=2\|PronType=Prs`, `POS=PRON\|PronType=Prs`, `AdvType=Cau\|POS=ADV`, `POS=PRON\|Person=3\|PronType=Prs\|Shared=No`, `NounType=Clf\|POS=NOUN`, `NameType=Sur\|POS=PROPN\|Shared=Yes`, `POS=NOUN\|Shared=Yes`, `ExtPos=ADV\|POS=ADV\|VerbForm=Conv`, `Degree=Pos\|POS=VERB\|Shared=No`, `NameType=Giv\|POS=PROPN\|Shared=No`, `Case=Loc\|NameType=Geo\|POS=PROPN`, `AdvType=Tim\|POS=ADV\|Tense=Past`, `AdvType=Tim\|POS=ADV\|Tense=Fut`, `ExtPos=AUX\|Mood=Pot\|POS=AUX`, `Case=Tem\|POS=NOUN\|Shared=No`, `ExtPos=VERB\|POS=VERB`, `Degree=Pos\|ExtPos=VERB\|POS=VERB`, `POS=CCONJ\|Shared=Yes`, `POS=ADP\|Shared=Yes`, `AdvType=Tim\|Aspect=Perf\|POS=ADV`, `POS=SCONJ\|Shared=No`, `Case=Loc\|ExtPos=NOUN\|POS=NOUN`, `NameType=Giv\|POS=PROPN\|Shared=Yes`, `POS=PART\|Shared=No`, `POS=PRON\|Person=1\|PronType=Prs\|Shared=Yes`, `POS=PRON\|PronType=Prs\|Shared=No`, `Case=Loc\|POS=NOUN\|Shared=No`, `ExtPos=NOUN\|POS=NOUN`, `POS=INTJ`, `POS=ADV\|Polarity=Neg\|Shared=No`, `Degree=Equ\|POS=ADP`, `Case=Loc\|POS=NOUN\|Shared=Yes`, `POS=PRON\|PronType=Prs\|Reflex=Yes\|Shared=No`, `POS=PRON\|PronType=Int\|Shared=No`, `POS=VERB\|Polarity=Neg\|VerbForm=Part`, `POS=SCONJ\|Shared=Yes`, `Degree=Pos\|POS=ADV\|Shared=No\|VerbForm=Conv`, `Case=Tem\|POS=NOUN\|Shared=Yes`, `Case=Loc\|NameType=Geo\|POS=PROPN\|Shared=Yes`, `AdvType=Tim\|POS=ADV\|Tense=Pres`, `POS=AUX\|Voice=Pass`, `NameType=Prs\|POS=PROPN\|Shared=Yes`, `NameType=Prs\|POS=PROPN\|Shared=No`, `POS=VERB\|Shared=Yes`, `Mood=Pot\|POS=AUX\|Shared=No`, `Mood=Nec\|POS=AUX`, `POS=PRON\|PronType=Dem\|Shared=Yes`, `POS=PRON\|Person=3\|PronType=Prs\|Shared=Yes`, `Degree=Pos\|ExtPos=ADV\|POS=ADV\|VerbForm=Conv`, `AdvType=Deg\|Degree=Cmp\|POS=ADV`, `POS=PRON\|PronType=Prs\|Reflex=Yes\|Shared=Yes`, `Degree=Pos\|ExtPos=VERB\|POS=VERB\|VerbForm=Part`, `POS=AUX\|Shared=Yes\|VerbType=Cop`, `POS=ADV\|Polarity=Neg\|Shared=Yes`, `AdvType=Tim\|POS=ADV\|Shared=Yes`, `POS=AUX\|Shared=No\|VerbType=Cop`, `POS=ADV\|Shared=No\|VerbForm=Conv`, `POS=PRON\|PronType=Dem\|Shared=No`, `NameType=Sur\|POS=PROPN\|Shared=No`, `ExtPos=AUX\|Mood=Des\|POS=AUX`, `POS=NUM\|Shared=No`, `POS=PRON\|PronType=Int\|Shared=Yes`, `POS=PRON\|Person=2\|PronType=Prs\|Shared=Yes`, `Case=Loc\|NameType=Geo\|POS=PROPN\|Shared=No`, `AdvType=Deg\|Degree=Sup\|POS=ADV`, `POS=PRON\|Person=2\|PronType=Prs\|Shared=No`, `Case=Loc\|NameType=Nat\|POS=PROPN\|Shared=No`, `NounType=Clf\|POS=NOUN\|Shared=No`, `Case=Loc\|NameType=Nat\|POS=PROPN\|Shared=Yes`, `Degree=Pos\|POS=ADV\|Shared=Yes\|VerbForm=Conv`, `ExtPos=VERB\|POS=VERB\|Polarity=Neg`, `POS=PRON\|Person=1\|PronType=Prs\|Shared=No`, `NounType=Clf\|POS=NOUN\|Shared=Yes`, `Degree=Equ\|POS=VERB\|Shared=Yes`, `Degree=Equ\|POS=ADV\|VerbForm=Conv`, `NumType=Ord\|POS=NUM`, `AdvType=Tim\|POS=ADV\|Shared=No`, `Case=Loc\|NounType=Clf\|POS=NOUN`, `AdvType=Deg\|Degree=Pos\|POS=ADV`, `POS=ADV\|Shared=No`, `POS=VERB\|Polarity=Neg\|Shared=No`, `AdvType=Tim\|Aspect=Perf\|POS=ADV\|Shared=Yes`, `Degree=Pos\|POS=VERB\|Shared=Yes`, `POS=VERB\|Shared=No\|VerbForm=Part`, `NumType=Ord\|POS=NUM\|Shared=Yes`, `Degree=Pos\|POS=VERB\|Shared=No\|VerbForm=Part`, `Degree=Pos\|POS=VERB\|Shared=Yes\|VerbForm=Part`, `AdvType=Tim\|POS=ADV\|Shared=No\|Tense=Fut`, `POS=ADV\|Shared=Yes\|VerbForm=Conv`, `AdvType=Tim\|Aspect=Perf\|POS=ADV\|Shared=No`, `ExtPos=INTJ\|POS=INTJ`, `Case=Tem\|NounType=Clf\|POS=NOUN`, `POS=SYM`, `AdvType=Tim\|ExtPos=ADV\|POS=ADV`, `NounType=Clf\|POS=NUM`, `Mood=Pot\|POS=AUX\|Shared=Yes`, `POS=NUM\|Shared=Yes`, `NumType=Ord\|POS=NUM\|Shared=No`, `ExtPos=PART\|POS=PART`, `AdvType=Deg\|Degree=Sup\|POS=ADV\|Shared=Yes`, `Case=Loc\|NounType=Clf\|POS=NOUN\|Shared=Yes`, `Degree=Equ\|POS=VERB\|Shared=Yes\|VerbForm=Part`, `AdvType=Tim\|POS=ADV\|Shared=Yes\|Tense=Pres`, `ExtPos=VERB\|POS=VERB\|VerbForm=Part`, `POS=INTJ\|Shared=Yes`, `POS=PRON\|PronType=Prs\|Shared=Yes`, `POS=PROPN`, `AdvType=Deg\|Degree=Sup\|POS=ADV\|Shared=No`, `Degree=Equ\|POS=VERB\|Shared=No`, `POS=ADV\|Polarity=Neg\|Shared=Yes\|VerbForm=Conv`, `Degree=Pos\|POS=NOUN`, `Mood=Des\|POS=AUX\|Shared=Yes`, `AdvType=Cau\|POS=ADV\|Shared=Yes`, `Case=Loc\|NameType=Nat\|NounType=Clf\|POS=PROPN`, `AdvType=Tim\|POS=ADV\|Shared=Yes\|Tense=Past`, `AdvType=Tim\|POS=ADV\|Shared=Yes\|Tense=Fut`, `Case=Loc\|NounType=Clf\|POS=NOUN\|Shared=No` |
| **`tagger`** | `n,代名詞,人称,他`, `n,代名詞,人称,止格`, `n,代名詞,人称,起格`, `n,代名詞,指示,*`, `n,代名詞,疑問,*`, `n,名詞,不可譲,属性`, `n,名詞,不可譲,疾病`, `n,名詞,不可譲,身体`, `n,名詞,主体,動物`, `n,名詞,主体,国名`, `n,名詞,主体,書物`, `n,名詞,主体,機関`, `n,名詞,主体,神仏`, `n,名詞,主体,集団`, `n,名詞,人,その他の人名`, `n,名詞,人,人`, `n,名詞,人,名`, `n,名詞,人,姓氏`, `n,名詞,人,役割`, `n,名詞,人,複合的人名`, `n,名詞,人,関係`, `n,名詞,制度,儀礼`, `n,名詞,制度,場`, `n,名詞,可搬,乗り物`, `n,名詞,可搬,伝達`, `n,名詞,可搬,成果物`, `n,名詞,可搬,糧食`, `n,名詞,可搬,道具`, `n,名詞,固定物,地名`, `n,名詞,固定物,地形`, `n,名詞,固定物,建造物`, `n,名詞,固定物,樹木`, `n,名詞,固定物,関係`, `n,名詞,外観,人`, `n,名詞,天象,天文`, `n,名詞,天象,怪異`, `n,名詞,天象,気象`, `n,名詞,度量衡,*`, `n,名詞,思考,思考`, `n,名詞,描写,形質`, `n,名詞,描写,態度`, `n,名詞,数量,*`, `n,名詞,時,*`, `n,名詞,行為,*`, `n,数詞,干支,*`, `n,数詞,数,*`, `n,数詞,数字,*`, `p,助詞,句末,*`, `p,助詞,句頭,*`, `p,助詞,接続,並列`, `p,助詞,接続,体言化`, `p,助詞,接続,属格`, `p,助詞,提示,*`, `p,感嘆詞,*,*`, `p,接尾辞,*,*`, `s,文字,*,*`, `s,記号,*,*`, `s,記号,一般,*`, `s,記号,句点,*`, `s,記号,括弧閉,*`, `s,記号,括弧開,*`, `s,記号,読点,*`, `v,前置詞,基盤,*`, `v,前置詞,源泉,*`, `v,前置詞,経由,*`, `v,前置詞,関係,*`, `v,副詞,判断,推定`, `v,副詞,判断,確定`, `v,副詞,判断,逆接`, `v,副詞,否定,体言否定`, `v,副詞,否定,有界`, `v,副詞,否定,無界`, `v,副詞,否定,禁止`, `v,副詞,描写,*`, `v,副詞,時相,変化`, `v,副詞,時相,完了`, `v,副詞,時相,将来`, `v,副詞,時相,恒常`, `v,副詞,時相,現在`, `v,副詞,時相,終局`, `v,副詞,時相,継起`, `v,副詞,時相,緊接`, `v,副詞,時相,過去`, `v,副詞,疑問,原因`, `v,副詞,疑問,反語`, `v,副詞,疑問,所在`, `v,副詞,程度,やや高度`, `v,副詞,程度,極度`, `v,副詞,程度,軽度`, `v,副詞,範囲,共同`, `v,副詞,範囲,総括`, `v,副詞,範囲,限定`, `v,副詞,頻度,偶発`, `v,副詞,頻度,重複`, `v,副詞,頻度,頻繁`, `v,助動詞,受動,*`, `v,助動詞,可能,*`, `v,助動詞,必要,*`, `v,助動詞,願望,*`, `v,動詞,変化,制度`, `v,動詞,変化,性質`, `v,動詞,変化,生物`, `v,動詞,存在,存在`, `v,動詞,描写,境遇`, `v,動詞,描写,形質`, `v,動詞,描写,態度`, `v,動詞,描写,量`, `v,動詞,行為,交流`, `v,動詞,行為,伝達`, `v,動詞,行為,使役`, `v,動詞,行為,儀礼`, `v,動詞,行為,分類`, `v,動詞,行為,動作`, `v,動詞,行為,姿勢`, `v,動詞,行為,役割`, `v,動詞,行為,得失`, `v,動詞,行為,態度`, `v,動詞,行為,生産`, `v,動詞,行為,移動`, `v,動詞,行為,設置`, `v,動詞,行為,飲食` |
| **`sud_shared`** | `O`, `No`, `Yes` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `TAG_ACC` | 92.28 |
| `POS_ACC` | 93.04 |
| `TAG_MICRO_P` | 0.00 |
| `TAG_MICRO_R` | 0.00 |
| `TAG_MICRO_F` | 0.00 |
| `DEP_UAS` | 80.48 |
| `DEP_LAS` | 75.22 |
| `SENTS_P` | 85.06 |
| `SENTS_R` | 92.25 |
| `SENTS_F` | 88.51 |
| `MORPH_ACC` | 90.48 |
| `SUD_SUBJECT_F` | 60.26 |
| `SUD_SUBJECT_P` | 66.20 |
| `SUD_SUBJECT_R` | 55.29 |
| `SUD_SHARED_F` | 55.67 |
| `SUD_SHARED_P` | 66.74 |
| `SUD_SHARED_R` | 47.74 |
| `SUD_SUBJECT_LOSS` | 31331.03 |
| `SUD_SHARED_LOSS` | 76610.68 |