| Feature | Description |
| --- | --- |
| **Name** | `lzh_sud_kyoto` |
| **Version** | `0.3.5` |
| **spaCy** | `>=3.8.14,<3.9.0` |
| **Default Pipeline** | `tok2vec`, `parser`, `morphologizer`, `tagger`, `sud_shared`, `han_lemma_lut`, `sud_subject_rule`, `sud_idiom`, `sent_join`, `lzh_upos_rules` |
| **Components** | `tok2vec`, `parser`, `morphologizer`, `tagger`, `sud_shared`, `han_lemma_lut`, `sud_subject_rule`, `sud_idiom`, `sent_join`, `lzh_upos_rules` |
| **Vectors** | 11444 keys, 11444 unique vectors (96 dimensions) |
| **Sources** | [SUD_Classical_Chinese-Kyoto](https://github.com/surfacesyntacticud/SUD_Classical_Chinese-Kyoto)<br>[Kanseki Repository (punctuation)](https://github.com/kanripo) |
| **License** | `CC BY-SA 4.0` |
| **Author** | [Sunflower AI](https://github.com/SunflowerAI/sud-spacy-parsers) |

### Label Scheme

<details>

<summary>View label scheme (340 labels for 4 components)</summary>

| Component | Labels |
| --- | --- |
| **`parser`** | `ROOT`, `cc`, `clf`, `comp:aux`, `comp:obj`, `comp:obl`, `comp:obl@lmod`, `comp:pred`, `comp@expl`, `compound`, `compound@redup`, `conj:coord`, `conj:coord@emb`, `dep`, `det`, `discourse`, `discourse@sp`, `dislocated`, `flat`, `flat@foreign`, `flat@vv`, `list`, `mod`, `mod@lmod`, `mod@tmod`, `parataxis`, `punct`, `subj`, `udep`, `udep@lmod`, `udep@tmod`, `unk`, `unk@expl`, `vocative` |
| **`morphologizer`** | `POS=VERB`, `POS=NOUN`, `POS=NUM`, `POS=PUNCT`, `POS=AUX\|VerbType=Cop`, `POS=ADV\|Polarity=Neg`, `POS=NOUN\|Shared=No`, `POS=ADV`, `Mood=Pot\|POS=AUX`, `Degree=Pos\|POS=ADJ\|VerbForm=Part`, `POS=PART`, `Degree=Pos\|POS=ADJ`, `POS=VERB\|VerbForm=Part`, `POS=ADV\|Shared=Yes`, `POS=PART\|Shared=Yes`, `POS=VERB\|Shared=No`, `POS=ADP`, `POS=ADV\|Polarity=Neg\|VerbForm=Conv`, `POS=PRON\|PronType=Dem`, `POS=SCONJ`, `POS=PRON\|Person=3\|PronType=Prs`, `ExtPos=ADV\|POS=ADV`, `POS=VERB\|Polarity=Neg`, `Case=Loc\|POS=NOUN`, `POS=ADV\|VerbForm=Conv`, `POS=PRON\|Person=1\|PronType=Prs`, `Case=Tem\|POS=NOUN`, `AdvType=Tim\|POS=ADV`, `POS=CCONJ`, `POS=PRON\|PronType=Int`, `Degree=Equ\|POS=VERB`, `POS=PRON\|PronType=Prs\|Reflex=Yes`, `NameType=Giv\|POS=PROPN`, `NameType=Prs\|POS=PROPN`, `Degree=Pos\|POS=ADV\|VerbForm=Conv`, `Mood=Des\|POS=AUX`, `POS=ADP\|Shared=No`, `NameType=Sur\|POS=PROPN`, `Degree=Equ\|POS=VERB\|VerbForm=Part`, `Case=Loc\|NameType=Nat\|POS=PROPN`, `POS=PRON\|Person=2\|PronType=Prs`, `POS=PRON\|PronType=Prs`, `AdvType=Cau\|POS=ADV`, `POS=PRON\|Person=3\|PronType=Prs\|Shared=No`, `NounType=Clf\|POS=NOUN`, `NameType=Sur\|POS=PROPN\|Shared=Yes`, `POS=NOUN\|Shared=Yes`, `ExtPos=ADV\|POS=ADV\|VerbForm=Conv`, `Degree=Pos\|POS=ADJ\|Shared=No`, `NameType=Giv\|POS=PROPN\|Shared=No`, `Case=Loc\|NameType=Geo\|POS=PROPN`, `AdvType=Tim\|POS=ADV\|Tense=Past`, `AdvType=Tim\|POS=ADV\|Tense=Fut`, `ExtPos=AUX\|Mood=Pot\|POS=AUX`, `Case=Tem\|POS=NOUN\|Shared=No`, `ExtPos=VERB\|POS=VERB`, `Degree=Pos\|ExtPos=VERB\|POS=ADJ`, `POS=CCONJ\|Shared=Yes`, `POS=ADP\|Shared=Yes`, `AdvType=Tim\|Aspect=Perf\|POS=ADV`, `POS=SCONJ\|Shared=No`, `Case=Loc\|ExtPos=NOUN\|POS=NOUN`, `NameType=Giv\|POS=PROPN\|Shared=Yes`, `POS=PART\|Shared=No`, `POS=PRON\|Person=1\|PronType=Prs\|Shared=Yes`, `POS=PRON\|PronType=Prs\|Shared=No`, `Case=Loc\|POS=NOUN\|Shared=No`, `ExtPos=NOUN\|POS=NOUN`, `POS=INTJ`, `POS=ADV\|Polarity=Neg\|Shared=No`, `Degree=Equ\|POS=ADP`, `Case=Loc\|POS=NOUN\|Shared=Yes`, `POS=PRON\|PronType=Prs\|Reflex=Yes\|Shared=No`, `POS=PRON\|PronType=Int\|Shared=No`, `POS=VERB\|Polarity=Neg\|VerbForm=Part`, `POS=SCONJ\|Shared=Yes`, `Degree=Pos\|POS=ADV\|Shared=No\|VerbForm=Conv`, `Case=Tem\|POS=NOUN\|Shared=Yes`, `Case=Loc\|NameType=Geo\|POS=PROPN\|Shared=Yes`, `AdvType=Tim\|POS=ADV\|Tense=Pres`, `POS=AUX\|Voice=Pass`, `NameType=Prs\|POS=PROPN\|Shared=Yes`, `NameType=Prs\|POS=PROPN\|Shared=No`, `POS=VERB\|Shared=Yes`, `Mood=Pot\|POS=AUX\|Shared=No`, `Mood=Nec\|POS=AUX`, `POS=PRON\|PronType=Dem\|Shared=Yes`, `POS=PRON\|Person=3\|PronType=Prs\|Shared=Yes`, `Degree=Pos\|ExtPos=ADV\|POS=ADV\|VerbForm=Conv`, `AdvType=Deg\|Degree=Cmp\|POS=ADV`, `POS=PRON\|PronType=Prs\|Reflex=Yes\|Shared=Yes`, `Degree=Pos\|ExtPos=VERB\|POS=ADJ\|VerbForm=Part`, `POS=AUX\|Shared=Yes\|VerbType=Cop`, `POS=ADV\|Polarity=Neg\|Shared=Yes`, `AdvType=Tim\|POS=ADV\|Shared=Yes`, `POS=AUX\|Shared=No\|VerbType=Cop`, `POS=ADV\|Shared=No\|VerbForm=Conv`, `POS=PRON\|PronType=Dem\|Shared=No`, `NameType=Sur\|POS=PROPN\|Shared=No`, `ExtPos=AUX\|Mood=Des\|POS=AUX`, `POS=NUM\|Shared=No`, `POS=PRON\|PronType=Int\|Shared=Yes`, `POS=PRON\|Person=2\|PronType=Prs\|Shared=Yes`, `Case=Loc\|NameType=Geo\|POS=PROPN\|Shared=No`, `AdvType=Deg\|Degree=Sup\|POS=ADV`, `POS=PRON\|Person=2\|PronType=Prs\|Shared=No`, `Case=Loc\|NameType=Nat\|POS=PROPN\|Shared=No`, `NounType=Clf\|POS=NOUN\|Shared=No`, `Case=Loc\|NameType=Nat\|POS=PROPN\|Shared=Yes`, `Degree=Pos\|POS=ADV\|Shared=Yes\|VerbForm=Conv`, `ExtPos=VERB\|POS=VERB\|Polarity=Neg`, `POS=PRON\|Person=1\|PronType=Prs\|Shared=No`, `NounType=Clf\|POS=NOUN\|Shared=Yes`, `Degree=Equ\|POS=VERB\|Shared=Yes`, `Degree=Equ\|POS=ADV\|VerbForm=Conv`, `NumType=Ord\|POS=NUM`, `AdvType=Tim\|POS=ADV\|Shared=No`, `Case=Loc\|NounType=Clf\|POS=NOUN`, `AdvType=Deg\|Degree=Pos\|POS=ADV`, `POS=ADV\|Shared=No`, `POS=VERB\|Polarity=Neg\|Shared=No`, `AdvType=Tim\|Aspect=Perf\|POS=ADV\|Shared=Yes`, `Degree=Pos\|POS=ADJ\|Shared=Yes`, `POS=VERB\|Shared=No\|VerbForm=Part`, `NumType=Ord\|POS=NUM\|Shared=Yes`, `Degree=Pos\|POS=ADJ\|Shared=No\|VerbForm=Part`, `Degree=Pos\|POS=ADJ\|Shared=Yes\|VerbForm=Part`, `AdvType=Tim\|POS=ADV\|Shared=No\|Tense=Fut`, `POS=ADV\|Shared=Yes\|VerbForm=Conv`, `AdvType=Tim\|Aspect=Perf\|POS=ADV\|Shared=No`, `ExtPos=INTJ\|POS=INTJ`, `Case=Tem\|NounType=Clf\|POS=NOUN`, `POS=SYM`, `AdvType=Tim\|ExtPos=ADV\|POS=ADV`, `NounType=Clf\|POS=NUM`, `Mood=Pot\|POS=AUX\|Shared=Yes`, `POS=NUM\|Shared=Yes`, `NumType=Ord\|POS=NUM\|Shared=No`, `ExtPos=PART\|POS=PART`, `AdvType=Deg\|Degree=Sup\|POS=ADV\|Shared=Yes`, `Case=Loc\|NounType=Clf\|POS=NOUN\|Shared=Yes`, `Degree=Equ\|POS=VERB\|Shared=Yes\|VerbForm=Part`, `AdvType=Tim\|POS=ADV\|Shared=Yes\|Tense=Pres`, `ExtPos=VERB\|POS=VERB\|VerbForm=Part`, `POS=INTJ\|Shared=Yes`, `POS=PRON\|PronType=Prs\|Shared=Yes`, `POS=PROPN`, `AdvType=Deg\|Degree=Sup\|POS=ADV\|Shared=No`, `Degree=Equ\|POS=VERB\|Shared=No`, `POS=ADV\|Polarity=Neg\|Shared=Yes\|VerbForm=Conv`, `Degree=Pos\|POS=NOUN`, `Mood=Des\|POS=AUX\|Shared=Yes`, `AdvType=Cau\|POS=ADV\|Shared=Yes`, `Case=Loc\|NameType=Nat\|NounType=Clf\|POS=PROPN`, `AdvType=Tim\|POS=ADV\|Shared=Yes\|Tense=Past`, `AdvType=Tim\|POS=ADV\|Shared=Yes\|Tense=Fut`, `Case=Loc\|NounType=Clf\|POS=NOUN\|Shared=No` |
| **`tagger`** | `0,n`, `0,p`, `0,s`, `0,v`, `1,代名詞`, `1,前置詞`, `1,副詞`, `1,助動詞`, `1,助詞`, `1,動詞`, `1,名詞`, `1,感嘆詞`, `1,接尾辞`, `1,数詞`, `1,文字`, `1,記号`, `2,*`, `2,一般`, `2,不可譲`, `2,主体`, `2,人`, `2,人称`, `2,判断`, `2,制度`, `2,受動`, `2,句末`, `2,句点`, `2,句頭`, `2,可搬`, `2,可能`, `2,否定`, `2,固定物`, `2,基盤`, `2,変化`, `2,外観`, `2,天象`, `2,存在`, `2,干支`, `2,度量衡`, `2,必要`, `2,思考`, `2,括弧閉`, `2,括弧開`, `2,指示`, `2,接続`, `2,描写`, `2,提示`, `2,数`, `2,数字`, `2,数量`, `2,時`, `2,時相`, `2,源泉`, `2,疑問`, `2,程度`, `2,範囲`, `2,経由`, `2,行為`, `2,読点`, `2,関係`, `2,頻度`, `2,願望`, `3,*`, `3,その他の人名`, `3,やや高度`, `3,並列`, `3,乗り物`, `3,交流`, `3,人`, `3,他`, `3,伝達`, `3,体言化`, `3,体言否定`, `3,使役`, `3,偶発`, `3,儀礼`, `3,共同`, `3,分類`, `3,制度`, `3,動作`, `3,動物`, `3,原因`, `3,反語`, `3,名`, `3,国名`, `3,地名`, `3,地形`, `3,場`, `3,境遇`, `3,変化`, `3,天文`, `3,姓氏`, `3,姿勢`, `3,存在`, `3,完了`, `3,将来`, `3,属性`, `3,属格`, `3,建造物`, `3,形質`, `3,役割`, `3,得失`, `3,思考`, `3,性質`, `3,怪異`, `3,恒常`, `3,態度`, `3,成果物`, `3,所在`, `3,推定`, `3,書物`, `3,有界`, `3,極度`, `3,樹木`, `3,機関`, `3,止格`, `3,気象`, `3,無界`, `3,現在`, `3,生物`, `3,生産`, `3,疾病`, `3,確定`, `3,神仏`, `3,禁止`, `3,移動`, `3,糧食`, `3,終局`, `3,継起`, `3,緊接`, `3,総括`, `3,複合的人名`, `3,設置`, `3,起格`, `3,身体`, `3,軽度`, `3,逆接`, `3,過去`, `3,道具`, `3,重複`, `3,量`, `3,関係`, `3,限定`, `3,集団`, `3,頻繁`, `3,飲食` |
| **`sud_shared`** | `O`, `No`, `Yes` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `TAG_ACC` | 91.97 |
| `POS_ACC` | 92.83 |
| `TAG_MICRO_P` | 0.00 |
| `TAG_MICRO_R` | 0.00 |
| `TAG_MICRO_F` | 0.00 |
| `DEP_UAS` | 80.48 |
| `DEP_LAS` | 75.22 |
| `SENTS_P` | 85.06 |
| `SENTS_R` | 92.25 |
| `SENTS_F` | 88.51 |
| `MORPH_ACC` | 90.26 |
| `SUD_SUBJECT_F` | 60.26 |
| `SUD_SUBJECT_P` | 66.20 |
| `SUD_SUBJECT_R` | 55.29 |
| `SUD_SHARED_F` | 56.22 |
| `SUD_SHARED_P` | 69.00 |
| `SUD_SHARED_R` | 47.43 |
| `SUD_SUBJECT_LOSS` | 31331.03 |
| `SUD_SHARED_LOSS` | 77328.15 |